# Job Vacancy App - Flutter Source

This folder contains the Dart source (`lib/`) and `pubspec.yaml` for the mobile
app. It talks to the backend at `https://jobs.mytoolshub.co.in/api`.

## ⚠️ Important - read before building

I wrote and carefully reviewed every file by hand (imports, method signatures,
model fields against the actual API responses), but **I could not run
`flutter analyze` or compile this myself** - this sandbox can't reach
`storage.googleapis.com` or `pub.dev`, which Flutter's tooling needs. So unlike
the PHP backend (which I ran live and tested end-to-end with real requests),
this Flutter code has been reviewed but not compiled. Please treat the first
build in Codespaces as the real verification step, and let me know if
`flutter analyze` turns up anything - I'll fix it immediately.

## Setup in GitHub Codespaces

1. Copy the `lib/` folder and `pubspec.yaml` into your Flutter project (or if
   this is a fresh project, put them in an empty folder first).
2. If `android/` and `ios/` folders don't exist yet, generate them:
   ```
   flutter create .
   ```
   This won't touch your existing `lib/` or `pubspec.yaml`.
3. Install dependencies:
   ```
   flutter pub get
   ```
4. Check for issues before building:
   ```
   flutter analyze
   ```
5. Build the APK:
   ```
   flutter build apk --release
   ```

## Android permissions to double-check

`image_picker` (profile photo) and `file_picker` (resume) usually merge their
own permissions into `android/app/src/main/AndroidManifest.xml`
automatically. If photo/resume picking fails on a real device, check that
your `android/app/build.gradle` `minSdkVersion` is at least 21, and that
`AndroidManifest.xml` doesn't already declare a conflicting
`READ_EXTERNAL_STORAGE` / `READ_MEDIA_IMAGES` entry.

## If the backend domain ever changes

Update the single constant in `lib/core/config.dart`:
```dart
static const String apiBaseUrl = 'https://jobs.mytoolshub.co.in/api';
```

## What's implemented

- Login / Signup / Logout (token stored locally, session re-checked on app start)
- Home: search by job title/company, filter by location, pagination
- Vacancy details + Apply (blocks duplicate apply, blocks applying to your own vacancy)
- Post Vacancy: full form, dynamic category → subcategory dropdown, goes to admin approval
- My Applications: list with status + applied date, tap through to vacancy details
- My Posted Jobs: list with approval/publish status + applicant count
- Applicants screen (per vacancy you posted): view resume, update status
- Profile: view/edit all fields, upload photo, upload/replace resume, view own resume
- Change Password: revokes your other devices' sessions, keeps this one logged in

## What's NOT built yet (matches the backend's current scope)

- Push notifications, saved jobs, job alerts, chat, featured jobs, payments -
  all deliberately out of scope for this MVP per the original spec.
