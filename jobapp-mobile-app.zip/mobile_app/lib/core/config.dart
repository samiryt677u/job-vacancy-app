/// App-wide constants. Update [apiBaseUrl] if the backend domain ever changes.
class AppConfig {
  AppConfig._();

  /// Base URL of the REST API (no trailing slash).
  static const String apiBaseUrl = 'https://jobs.mytoolshub.co.in/api';

  /// Matches RESUME_ALLOWED_EXT in config/config.php on the backend.
  static const List<String> resumeAllowedExtensions = ['pdf', 'doc', 'docx'];

  /// Matches RESUME_MAX_SIZE (5 MB) in config/config.php.
  static const int resumeMaxSizeBytes = 5 * 1024 * 1024;

  /// Matches PHOTO_ALLOWED_EXT in config/config.php.
  static const List<String> photoAllowedExtensions = ['jpg', 'jpeg', 'png'];

  /// Matches PHOTO_MAX_SIZE (2 MB) in config/config.php.
  static const int photoMaxSizeBytes = 2 * 1024 * 1024;

  static const List<String> applicationStatuses = [
    'applied',
    'shortlisted',
    'rejected',
    'selected',
  ];
}
