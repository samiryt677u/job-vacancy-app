import 'package:intl/intl.dart';

/// Formats the "yyyy-MM-dd HH:mm:ss" datetime strings the backend sends
/// (MySQL DATETIME format) into a friendly display string.
class DateFmt {
  DateFmt._();

  static final _display = DateFormat('d MMM yyyy, h:mm a');
  static final _displayShort = DateFormat('d MMM yyyy');

  static String full(String isoLike) {
    try {
      return _display.format(DateTime.parse(isoLike));
    } catch (_) {
      return isoLike;
    }
  }

  static String short(String isoLike) {
    try {
      return _displayShort.format(DateTime.parse(isoLike));
    } catch (_) {
      return isoLike;
    }
  }
}
