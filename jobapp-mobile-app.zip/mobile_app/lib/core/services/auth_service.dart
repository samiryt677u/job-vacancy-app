import 'package:flutter/foundation.dart';

import '../api/api_client.dart';
import '../api/api_exception.dart';
import '../models/user.dart';
import 'token_storage.dart';

enum AuthStatus { unknown, authenticated, unauthenticated }

/// Holds the current login session for the whole app. [checkSession] is
/// called once on startup (see main.dart / SplashScreen) to verify a
/// locally stored token is still valid before deciding which screen to
/// show first.
class AuthService extends ChangeNotifier {
  final ApiClient _api;
  final TokenStorage _tokenStorage;

  AuthService(this._api, this._tokenStorage);

  AuthStatus status = AuthStatus.unknown;
  AppUser? currentUser;

  Future<void> checkSession() async {
    final token = await _tokenStorage.readToken();
    if (token == null || token.isEmpty) {
      status = AuthStatus.unauthenticated;
      notifyListeners();
      return;
    }
    try {
      final response = await _api.get('/auth/me.php');
      final userJson = response['data']['user'] as Map<String, dynamic>;
      currentUser = AppUser.fromJson(userJson);
      status = AuthStatus.authenticated;
    } on ApiException {
      await _tokenStorage.clear();
      currentUser = null;
      status = AuthStatus.unauthenticated;
    }
    notifyListeners();
  }

  Future<void> login({
    required String mobile,
    required String password,
    String? deviceInfo,
  }) async {
    final response = await _api.post(
      '/auth/login.php',
      auth: false,
      body: {
        'mobile': mobile,
        'password': password,
        if (deviceInfo != null) 'device_info': deviceInfo,
      },
    );
    await _handleAuthSuccess(response);
  }

  Future<void> signup({
    required String mobile,
    required String password,
    String? deviceInfo,
  }) async {
    final response = await _api.post(
      '/auth/signup.php',
      auth: false,
      body: {
        'mobile': mobile,
        'password': password,
        if (deviceInfo != null) 'device_info': deviceInfo,
      },
    );
    await _handleAuthSuccess(response);
  }

  Future<void> _handleAuthSuccess(Map<String, dynamic> response) async {
    final data = response['data'] as Map<String, dynamic>;
    final token = data['token'] as String;
    final user = AppUser.fromJson(data['user'] as Map<String, dynamic>);

    await _tokenStorage.saveSession(token: token, userId: user.id, mobile: user.mobile);
    currentUser = user;
    status = AuthStatus.authenticated;
    notifyListeners();
  }

  /// Called after a password change, which revokes this token server-side
  /// and issues a fresh one so the current device isn't logged out.
  Future<void> replaceToken(String newToken) async {
    final user = currentUser;
    if (user == null) return;
    await _tokenStorage.saveSession(token: newToken, userId: user.id, mobile: user.mobile);
  }

  Future<void> logout() async {
    try {
      await _api.post('/auth/logout.php');
    } on ApiException {
      // Still clear the local session even if the network call failed -
      // the user asked to log out and expects it to happen either way.
    }
    await _tokenStorage.clear();
    currentUser = null;
    status = AuthStatus.unauthenticated;
    notifyListeners();
  }
}
