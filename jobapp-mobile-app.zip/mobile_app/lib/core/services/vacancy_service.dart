import '../api/api_client.dart';
import '../models/application.dart';
import '../models/category.dart';
import '../models/vacancy.dart';

class HomeFeedResult {
  final List<VacancySummary> vacancies;
  final int page;
  final int totalPages;

  const HomeFeedResult({
    required this.vacancies,
    required this.page,
    required this.totalPages,
  });
}

class CategoryData {
  final List<JobCategory> categories;
  final List<JobSubcategory> subcategories;

  const CategoryData(this.categories, this.subcategories);

  List<JobSubcategory> subcategoriesFor(int categoryId) =>
      subcategories.where((s) => s.categoryId == categoryId).toList();
}

class VacancyApplicants {
  final String jobTitle;
  final List<Applicant> applicants;

  const VacancyApplicants(this.jobTitle, this.applicants);
}

class VacancyService {
  final ApiClient _api;
  VacancyService(this._api);

  Future<CategoryData> getCategories() async {
    final response = await _api.get('/vacancies/categories.php', auth: false);
    final data = response['data'] as Map<String, dynamic>;
    final categories = (data['categories'] as List)
        .map((e) => JobCategory.fromJson(e as Map<String, dynamic>))
        .toList();
    final subcategories = (data['subcategories'] as List)
        .map((e) => JobSubcategory.fromJson(e as Map<String, dynamic>))
        .toList();
    return CategoryData(categories, subcategories);
  }

  Future<HomeFeedResult> getHomeFeed({
    String? query,
    String? location,
    int? categoryId,
    int page = 1,
  }) async {
    final response = await _api.get(
      '/vacancies/home.php',
      auth: false,
      query: {
        if (query != null && query.isNotEmpty) 'q': query,
        if (location != null && location.isNotEmpty) 'location': location,
        if (categoryId != null) 'category_id': categoryId,
        'page': page,
      },
    );
    final data = response['data'] as Map<String, dynamic>;
    final vacancies = (data['vacancies'] as List)
        .map((e) => VacancySummary.fromJson(e as Map<String, dynamic>))
        .toList();
    final pagination = data['pagination'] as Map<String, dynamic>;
    return HomeFeedResult(
      vacancies: vacancies,
      page: pagination['page'] as int,
      totalPages: pagination['total_pages'] as int,
    );
  }

  Future<VacancyDetail> getDetail(int id) async {
    final response = await _api.get('/vacancies/detail.php', query: {'id': id});
    return VacancyDetail.fromJson(response['data'] as Map<String, dynamic>);
  }

  Future<int> create(Map<String, dynamic> fields) async {
    final response = await _api.post('/vacancies/create.php', body: fields);
    final data = response['data'] as Map<String, dynamic>;
    return data['vacancy_id'] as int;
  }

  Future<List<MyPostedVacancy>> getMyPosted() async {
    final response = await _api.get('/vacancies/my_posted.php');
    final data = response['data'] as Map<String, dynamic>;
    return (data['vacancies'] as List)
        .map((e) => MyPostedVacancy.fromJson(e as Map<String, dynamic>))
        .toList();
  }

  Future<VacancyApplicants> getApplicants(int vacancyId) async {
    final response = await _api.get('/vacancies/applicants.php', query: {'vacancy_id': vacancyId});
    final data = response['data'] as Map<String, dynamic>;
    final vacancy = data['vacancy'] as Map<String, dynamic>;
    final applicants = (data['applicants'] as List)
        .map((e) => Applicant.fromJson(e as Map<String, dynamic>))
        .toList();
    return VacancyApplicants(vacancy['job_title'] as String, applicants);
  }
}
