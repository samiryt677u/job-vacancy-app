import '../api/api_client.dart';
import '../models/application.dart';
import 'file_open_helper.dart';

class ApplicationService {
  final ApiClient _api;
  ApplicationService(this._api);

  Future<int> apply(int vacancyId) async {
    final response = await _api.post('/applications/apply.php', body: {'vacancy_id': vacancyId});
    final data = response['data'] as Map<String, dynamic>;
    return data['application_id'] as int;
  }

  Future<List<MyApplication>> getMyApplications() async {
    final response = await _api.get('/applications/my_applications.php');
    final data = response['data'] as Map<String, dynamic>;
    return (data['applications'] as List)
        .map((e) => MyApplication.fromJson(e as Map<String, dynamic>))
        .toList();
  }

  Future<void> updateStatus({required int applicationId, required String status}) async {
    await _api.post('/applications/update_status.php', body: {
      'application_id': applicationId,
      'status': status,
    });
  }

  /// Recruiter action: downloads and opens one applicant's resume.
  /// Only succeeds if the caller owns the vacancy that application belongs to
  /// - the backend enforces this, this just surfaces whatever error it returns.
  Future<void> viewApplicantResume({
    required int applicationId,
    required String fileName,
  }) async {
    final bytes = await _api.getBytes(
      '/applications/resume_view.php',
      query: {'application_id': applicationId},
    );
    await FileOpenHelper.saveAndOpen(bytes: bytes, fileName: fileName);
  }
}
