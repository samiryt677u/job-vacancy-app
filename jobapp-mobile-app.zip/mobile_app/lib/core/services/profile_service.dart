import '../api/api_client.dart';
import '../models/profile.dart';
import 'file_open_helper.dart';

class ProfileData {
  final UserProfile profile;
  final ResumeInfo? resume;

  const ProfileData(this.profile, this.resume);
}

class ProfileService {
  final ApiClient _api;
  ProfileService(this._api);

  Future<ProfileData> getProfile() async {
    final response = await _api.get('/profile/get.php');
    final data = response['data'] as Map<String, dynamic>;
    final profile = UserProfile.fromJson(data['profile'] as Map<String, dynamic>);
    final resumeJson = data['resume'] as Map<String, dynamic>?;
    return ProfileData(profile, resumeJson != null ? ResumeInfo.fromJson(resumeJson) : null);
  }

  Future<void> updateProfile(UserProfile profile) async {
    await _api.post('/profile/update.php', body: profile.toJson());
  }

  Future<String> uploadPhoto(String filePath) async {
    final response = await _api.uploadFile(
      '/profile/upload_photo.php',
      fileField: 'photo',
      filePath: filePath,
    );
    final data = response['data'] as Map<String, dynamic>;
    return data['photo_url'] as String;
  }

  Future<void> uploadResume(String filePath) async {
    await _api.uploadFile('/profile/upload_resume.php', fileField: 'resume', filePath: filePath);
  }

  Future<void> viewOwnResume({required String fileName}) async {
    final bytes = await _api.getBytes('/profile/resume_download.php');
    await FileOpenHelper.saveAndOpen(bytes: bytes, fileName: fileName);
  }

  /// Returns the fresh token issued after a successful password change.
  Future<String> changePassword({
    required String currentPassword,
    required String newPassword,
    String? deviceInfo,
  }) async {
    final response = await _api.post('/profile/change_password.php', body: {
      'current_password': currentPassword,
      'new_password': newPassword,
      if (deviceInfo != null) 'device_info': deviceInfo,
    });
    final data = response['data'] as Map<String, dynamic>;
    return data['token'] as String;
  }
}
