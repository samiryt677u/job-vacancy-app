import 'dart:io';

import 'package:open_filex/open_filex.dart';
import 'package:path_provider/path_provider.dart';

/// Used for resumes: the file bytes come from an authenticated API call
/// (so they can't just be opened via a public URL), get written to a temp
/// file, then handed to the OS's default PDF/Word viewer.
class FileOpenHelper {
  static Future<void> saveAndOpen({
    required List<int> bytes,
    required String fileName,
  }) async {
    final dir = await getTemporaryDirectory();
    final safeName = fileName.replaceAll(RegExp(r'[^A-Za-z0-9._-]'), '_');
    final file = File('${dir.path}/$safeName');
    await file.writeAsBytes(bytes, flush: true);
    await OpenFilex.open(file.path);
  }
}
