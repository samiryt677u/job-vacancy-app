import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;

import '../config.dart';
import '../services/token_storage.dart';
import 'api_exception.dart';

/// Thin wrapper around package:http that:
///  - prefixes every request with [AppConfig.apiBaseUrl]
///  - attaches "Authorization: Bearer <token>" automatically when available
///  - decodes the backend's {success, message, data, errors} envelope
///  - turns any failure (network or API-level) into an [ApiException]
class ApiClient {
  final TokenStorage _tokenStorage;

  ApiClient(this._tokenStorage);

  Uri _uri(String path) {
    final cleanPath = path.startsWith('/') ? path : '/$path';
    return Uri.parse('${AppConfig.apiBaseUrl}$cleanPath');
  }

  Uri _uriWithQuery(String path, Map<String, dynamic>? query) {
    final base = _uri(path);
    if (query == null || query.isEmpty) return base;
    final params = <String, String>{};
    query.forEach((key, value) {
      if (value != null) params[key] = value.toString();
    });
    return base.replace(queryParameters: params);
  }

  Future<Map<String, String>> _headers({required bool auth, required bool json}) async {
    final headers = <String, String>{};
    if (json) {
      headers['Content-Type'] = 'application/json';
    }
    if (auth) {
      final token = await _tokenStorage.readToken();
      if (token != null && token.isNotEmpty) {
        headers['Authorization'] = 'Bearer $token';
      }
    }
    return headers;
  }

  Map<String, dynamic> _decode(http.Response response) {
    Map<String, dynamic> body;
    try {
      body = jsonDecode(response.body) as Map<String, dynamic>;
    } catch (_) {
      throw ApiException(
        'Unexpected server response. Please try again later.',
        statusCode: response.statusCode,
      );
    }

    if (body['success'] == true) {
      return body;
    }

    throw ApiException(
      (body['message'] as String?) ?? 'Something went wrong.',
      statusCode: response.statusCode,
      fieldErrors: (body['errors'] as Map<String, dynamic>?) ?? const {},
    );
  }

  /// GET request. [auth] defaults to true - pass false for public endpoints
  /// you deliberately want to call without a token even if one is stored.
  Future<Map<String, dynamic>> get(
    String path, {
    Map<String, dynamic>? query,
    bool auth = true,
  }) async {
    try {
      final response = await http.get(
        _uriWithQuery(path, query),
        headers: await _headers(auth: auth, json: false),
      );
      return _decode(response);
    } on ApiException {
      rethrow;
    } on SocketException {
      throw ApiException('No internet connection. Please check your network.');
    } catch (_) {
      throw ApiException('Could not connect to the server. Please try again.');
    }
  }

  /// POST request with a JSON body.
  Future<Map<String, dynamic>> post(
    String path, {
    Map<String, dynamic>? body,
    bool auth = true,
  }) async {
    try {
      final response = await http.post(
        _uri(path),
        headers: await _headers(auth: auth, json: true),
        body: jsonEncode(body ?? const {}),
      );
      return _decode(response);
    } on ApiException {
      rethrow;
    } on SocketException {
      throw ApiException('No internet connection. Please check your network.');
    } catch (_) {
      throw ApiException('Could not connect to the server. Please try again.');
    }
  }

  /// Multipart file upload (resume / profile photo).
  /// [fileField] must match the backend's expected form field name
  /// ("resume" or "photo").
  Future<Map<String, dynamic>> uploadFile(
    String path, {
    required String fileField,
    required String filePath,
    Map<String, String>? extraFields,
  }) async {
    try {
      final request = http.MultipartRequest('POST', _uri(path));

      final token = await _tokenStorage.readToken();
      if (token != null && token.isNotEmpty) {
        request.headers['Authorization'] = 'Bearer $token';
      }
      if (extraFields != null) {
        request.fields.addAll(extraFields);
      }
      request.files.add(await http.MultipartFile.fromPath(fileField, filePath));

      final streamed = await request.send();
      final response = await http.Response.fromStream(streamed);
      return _decode(response);
    } on ApiException {
      rethrow;
    } on SocketException {
      throw ApiException('No internet connection. Please check your network.');
    } catch (_) {
      throw ApiException('Could not upload the file. Please try again.');
    }
  }

  /// Downloads a binary file (a resume) that requires the Bearer token.
  /// If the server responds with a JSON error instead of a file (e.g. 404,
  /// 403), this decodes it the normal way so the caller gets a proper
  /// [ApiException] with the real message rather than garbage bytes.
  Future<List<int>> getBytes(String path, {Map<String, dynamic>? query}) async {
    try {
      final response = await http.get(
        _uriWithQuery(path, query),
        headers: await _headers(auth: true, json: false),
      );

      final contentType = response.headers['content-type'] ?? '';
      if (contentType.contains('application/json')) {
        _decode(response); // always throws here - these endpoints only send JSON on error
      }
      if (response.statusCode != 200) {
        throw ApiException('Could not download the file.', statusCode: response.statusCode);
      }
      return response.bodyBytes;
    } on ApiException {
      rethrow;
    } on SocketException {
      throw ApiException('No internet connection. Please check your network.');
    } catch (_) {
      throw ApiException('Could not download the file. Please try again.');
    }
  }
}
