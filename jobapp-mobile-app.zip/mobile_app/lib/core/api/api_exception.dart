/// Thrown whenever the API returns success:false, or the request fails at
/// the network level. Carries enough detail for a screen to show either a
/// generic error message or field-specific validation errors.
class ApiException implements Exception {
  final String message;
  final int statusCode;
  final Map<String, dynamic> fieldErrors;

  ApiException(this.message, {this.statusCode = 0, this.fieldErrors = const {}});

  /// True when the server responded 401 (missing/expired/invalid token).
  bool get isUnauthorized => statusCode == 401;

  /// True when the server responded 403 (blocked account / not the owner).
  bool get isForbidden => statusCode == 403;

  @override
  String toString() => message;
}
