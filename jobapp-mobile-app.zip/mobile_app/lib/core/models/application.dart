/// An item in "My Applications" - the applicant's own view of one application.
class MyApplication {
  final int id;
  final int vacancyId;
  final String jobTitle;
  final String companyName;
  final String city;
  final String state;
  final String status; // applied | shortlisted | rejected | selected
  final String appliedAt;

  const MyApplication({
    required this.id,
    required this.vacancyId,
    required this.jobTitle,
    required this.companyName,
    required this.city,
    required this.state,
    required this.status,
    required this.appliedAt,
  });

  factory MyApplication.fromJson(Map<String, dynamic> json) => MyApplication(
        id: json['id'] as int,
        vacancyId: json['vacancy_id'] as int,
        jobTitle: json['job_title'] as String,
        companyName: json['company_name'] as String,
        city: json['city'] as String,
        state: json['state'] as String,
        status: json['status'] as String,
        appliedAt: json['applied_at'] as String,
      );
}

/// The recruiter's view of one applicant against one of their vacancies.
class Applicant {
  final int applicationId;
  final String? name;
  final String mobile;
  final String? qualification;
  final String? experience;
  final int? resumeId;
  final String? resumeFileName;
  final String? resumeFileType;
  final String status;
  final String appliedAt;

  const Applicant({
    required this.applicationId,
    this.name,
    required this.mobile,
    this.qualification,
    this.experience,
    this.resumeId,
    this.resumeFileName,
    this.resumeFileType,
    required this.status,
    required this.appliedAt,
  });

  bool get hasResume => resumeId != null;

  factory Applicant.fromJson(Map<String, dynamic> json) {
    final resume = json['resume'] as Map<String, dynamic>?;
    return Applicant(
      applicationId: json['application_id'] as int,
      name: json['name'] as String?,
      mobile: json['mobile'] as String,
      qualification: json['qualification'] as String?,
      experience: json['experience'] as String?,
      resumeId: resume?['id'] as int?,
      resumeFileName: resume?['file_name'] as String?,
      resumeFileType: resume?['file_type'] as String?,
      status: json['status'] as String,
      appliedAt: json['applied_at'] as String,
    );
  }
}
