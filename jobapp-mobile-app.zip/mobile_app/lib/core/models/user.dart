class AppUser {
  final int id;
  final String mobile;

  const AppUser({required this.id, required this.mobile});

  factory AppUser.fromJson(Map<String, dynamic> json) => AppUser(
        id: json['id'] as int,
        mobile: json['mobile'] as String,
      );
}
