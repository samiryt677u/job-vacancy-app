class JobCategory {
  final int id;
  final String name;

  const JobCategory({required this.id, required this.name});

  factory JobCategory.fromJson(Map<String, dynamic> json) => JobCategory(
        id: json['id'] as int,
        name: json['name'] as String,
      );
}

class JobSubcategory {
  final int id;
  final int categoryId;
  final String name;

  const JobSubcategory({
    required this.id,
    required this.categoryId,
    required this.name,
  });

  factory JobSubcategory.fromJson(Map<String, dynamic> json) => JobSubcategory(
        id: json['id'] as int,
        categoryId: json['category_id'] as int,
        name: json['name'] as String,
      );
}
