class ResumeInfo {
  final int id;
  final String fileName;
  final String fileType;
  final int fileSize;
  final String uploadedAt;

  const ResumeInfo({
    required this.id,
    required this.fileName,
    required this.fileType,
    required this.fileSize,
    required this.uploadedAt,
  });

  factory ResumeInfo.fromJson(Map<String, dynamic> json) => ResumeInfo(
        id: json['id'] as int,
        fileName: json['file_name'] as String,
        fileType: json['file_type'] as String,
        fileSize: json['file_size'] as int,
        uploadedAt: json['uploaded_at'] as String,
      );
}

class UserProfile {
  final String? photoUrl;
  final String? name;
  final String? email;
  final String? address;
  final String? qualification;
  final String? experience;
  final String? skills;
  final String? about;

  const UserProfile({
    this.photoUrl,
    this.name,
    this.email,
    this.address,
    this.qualification,
    this.experience,
    this.skills,
    this.about,
  });

  factory UserProfile.empty() => const UserProfile();

  factory UserProfile.fromJson(Map<String, dynamic> json) => UserProfile(
        photoUrl: json['photo_url'] as String?,
        name: json['name'] as String?,
        email: json['email'] as String?,
        address: json['address'] as String?,
        qualification: json['qualification'] as String?,
        experience: json['experience'] as String?,
        skills: json['skills'] as String?,
        about: json['about'] as String?,
      );

  Map<String, dynamic> toJson() => {
        'name': name,
        'email': email,
        'address': address,
        'qualification': qualification,
        'experience': experience,
        'skills': skills,
        'about': about,
      };

  UserProfile copyWith({
    String? photoUrl,
    String? name,
    String? email,
    String? address,
    String? qualification,
    String? experience,
    String? skills,
    String? about,
  }) =>
      UserProfile(
        photoUrl: photoUrl ?? this.photoUrl,
        name: name ?? this.name,
        email: email ?? this.email,
        address: address ?? this.address,
        qualification: qualification ?? this.qualification,
        experience: experience ?? this.experience,
        skills: skills ?? this.skills,
        about: about ?? this.about,
      );
}
