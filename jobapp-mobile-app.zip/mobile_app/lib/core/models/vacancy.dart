/// A single card on the Home feed / search results.
class VacancySummary {
  final int id;
  final String companyName;
  final String jobTitle;
  final String city;
  final String state;
  final String? salary;
  final String? experience;
  final String? qualification;
  final String category;
  final String postedAt;

  const VacancySummary({
    required this.id,
    required this.companyName,
    required this.jobTitle,
    required this.city,
    required this.state,
    this.salary,
    this.experience,
    this.qualification,
    required this.category,
    required this.postedAt,
  });

  factory VacancySummary.fromJson(Map<String, dynamic> json) => VacancySummary(
        id: json['id'] as int,
        companyName: json['company_name'] as String,
        jobTitle: json['job_title'] as String,
        city: json['city'] as String,
        state: json['state'] as String,
        salary: json['salary'] as String?,
        experience: json['experience'] as String?,
        qualification: json['qualification'] as String?,
        category: json['category'] as String? ?? '',
        postedAt: json['posted_at'] as String,
      );
}

/// Full vacancy details shown on the Vacancy Details screen.
class VacancyDetail {
  final int id;
  final String companyName;
  final String jobTitle;
  final String? category;
  final String? subcategory;
  final String state;
  final String city;
  final String? salary;
  final String? ageLimit;
  final String? qualification;
  final String? experience;
  final String jobDescription;
  final String contactPerson;
  final String contactNumber;
  final String postedAt;
  final bool alreadyApplied;

  const VacancyDetail({
    required this.id,
    required this.companyName,
    required this.jobTitle,
    this.category,
    this.subcategory,
    required this.state,
    required this.city,
    this.salary,
    this.ageLimit,
    this.qualification,
    this.experience,
    required this.jobDescription,
    required this.contactPerson,
    required this.contactNumber,
    required this.postedAt,
    required this.alreadyApplied,
  });

  factory VacancyDetail.fromJson(Map<String, dynamic> json) => VacancyDetail(
        id: json['id'] as int,
        companyName: json['company_name'] as String,
        jobTitle: json['job_title'] as String,
        category: json['category'] as String?,
        subcategory: json['subcategory'] as String?,
        state: json['state'] as String,
        city: json['city'] as String,
        salary: json['salary'] as String?,
        ageLimit: json['age_limit'] as String?,
        qualification: json['qualification'] as String?,
        experience: json['experience'] as String?,
        jobDescription: json['job_description'] as String? ?? '',
        contactPerson: json['contact_person'] as String,
        contactNumber: json['contact_number'] as String,
        postedAt: json['posted_at'] as String,
        alreadyApplied: json['already_applied'] as bool? ?? false,
      );
}

/// An item in the "My Posted Jobs" tab - includes moderation status,
/// since a user can see their own pending/rejected vacancies too.
class MyPostedVacancy {
  final int id;
  final String companyName;
  final String jobTitle;
  final String city;
  final String state;
  final String approvalStatus; // pending | approved | rejected
  final String publishStatus; // published | unpublished
  final String? rejectionReason;
  final int applicantCount;
  final String postedAt;

  const MyPostedVacancy({
    required this.id,
    required this.companyName,
    required this.jobTitle,
    required this.city,
    required this.state,
    required this.approvalStatus,
    required this.publishStatus,
    this.rejectionReason,
    required this.applicantCount,
    required this.postedAt,
  });

  factory MyPostedVacancy.fromJson(Map<String, dynamic> json) => MyPostedVacancy(
        id: json['id'] as int,
        companyName: json['company_name'] as String,
        jobTitle: json['job_title'] as String,
        city: json['city'] as String,
        state: json['state'] as String,
        approvalStatus: json['approval_status'] as String,
        publishStatus: json['publish_status'] as String,
        rejectionReason: json['rejection_reason'] as String?,
        applicantCount: json['applicant_count'] as int? ?? 0,
        postedAt: json['posted_at'] as String,
      );
}
