import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'core/api/api_client.dart';
import 'core/services/application_service.dart';
import 'core/services/auth_service.dart';
import 'core/services/profile_service.dart';
import 'core/services/token_storage.dart';
import 'core/services/vacancy_service.dart';
import 'core/theme/app_theme.dart';
import 'features/auth/splash_screen.dart';

void main() {
  runApp(const JobVacancyApp());
}

class JobVacancyApp extends StatelessWidget {
  const JobVacancyApp({super.key});

  @override
  Widget build(BuildContext context) {
    final tokenStorage = TokenStorage();
    final apiClient = ApiClient(tokenStorage);

    return MultiProvider(
      providers: [
        Provider<ApiClient>.value(value: apiClient),
        Provider<VacancyService>(create: (_) => VacancyService(apiClient)),
        Provider<ApplicationService>(create: (_) => ApplicationService(apiClient)),
        Provider<ProfileService>(create: (_) => ProfileService(apiClient)),
        ChangeNotifierProvider<AuthService>(create: (_) => AuthService(apiClient, tokenStorage)),
      ],
      child: MaterialApp(
        title: 'Job Vacancy',
        debugShowCheckedModeBanner: false,
        theme: AppTheme.light(),
        home: const SplashScreen(),
      ),
    );
  }
}
