import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

import '../../core/api/api_exception.dart';
import '../../core/config.dart';
import '../../core/models/profile.dart';
import '../../core/services/auth_service.dart';
import '../../core/services/profile_service.dart';
import '../../core/theme/app_theme.dart';
import '../../shared/widgets/async_state_views.dart';
import '../auth/login_screen.dart';
import 'change_password_screen.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  bool _loading = true;
  String? _error;

  UserProfile? _profile;
  ResumeInfo? _resume;

  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _addressController = TextEditingController();
  final _qualificationController = TextEditingController();
  final _experienceController = TextEditingController();
  final _skillsController = TextEditingController();
  final _aboutController = TextEditingController();

  bool _saving = false;
  bool _uploadingPhoto = false;
  bool _uploadingResume = false;
  bool _viewingResume = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _addressController.dispose();
    _qualificationController.dispose();
    _experienceController.dispose();
    _skillsController.dispose();
    _aboutController.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final data = await context.read<ProfileService>().getProfile();
      setState(() {
        _profile = data.profile;
        _resume = data.resume;
        _nameController.text = data.profile.name ?? '';
        _emailController.text = data.profile.email ?? '';
        _addressController.text = data.profile.address ?? '';
        _qualificationController.text = data.profile.qualification ?? '';
        _experienceController.text = data.profile.experience ?? '';
        _skillsController.text = data.profile.skills ?? '';
        _aboutController.text = data.profile.about ?? '';
      });
    } on ApiException catch (e) {
      setState(() => _error = e.message);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _save() async {
    setState(() => _saving = true);
    try {
      final updated = UserProfile(
        photoUrl: _profile?.photoUrl,
        name: _nameController.text.trim(),
        email: _emailController.text.trim(),
        address: _addressController.text.trim(),
        qualification: _qualificationController.text.trim(),
        experience: _experienceController.text.trim(),
        skills: _skillsController.text.trim(),
        about: _aboutController.text.trim(),
      );
      await context.read<ProfileService>().updateProfile(updated);
      setState(() => _profile = updated);
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text('Profile updated successfully.')));
      }
    } on ApiException catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
      }
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Future<void> _pickAndUploadPhoto() async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.gallery, imageQuality: 85);
    if (picked == null) return;

    final ext = picked.path.split('.').last.toLowerCase();
    if (!AppConfig.photoAllowedExtensions.contains(ext)) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Please select a ${AppConfig.photoAllowedExtensions.join('/')} image.')),
        );
      }
      return;
    }
    final size = await File(picked.path).length();
    if (size > AppConfig.photoMaxSizeBytes) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text('Photo is too large. Maximum size is 2 MB.')));
      }
      return;
    }

    setState(() => _uploadingPhoto = true);
    try {
      final photoUrl = await context.read<ProfileService>().uploadPhoto(picked.path);
      setState(() => _profile = _profile?.copyWith(photoUrl: photoUrl));
    } on ApiException catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
      }
    } finally {
      if (mounted) setState(() => _uploadingPhoto = false);
    }
  }

  Future<void> _pickAndUploadResume() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: AppConfig.resumeAllowedExtensions,
    );
    if (result == null || result.files.single.path == null) return;

    final path = result.files.single.path!;
    final size = result.files.single.size;
    if (size > AppConfig.resumeMaxSizeBytes) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text('Resume is too large. Maximum size is 5 MB.')));
      }
      return;
    }

    setState(() => _uploadingResume = true);
    try {
      await context.read<ProfileService>().uploadResume(path);
      await _load();
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text('Resume uploaded successfully.')));
      }
    } on ApiException catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
      }
    } finally {
      if (mounted) setState(() => _uploadingResume = false);
    }
  }

  Future<void> _viewResume() async {
    if (_resume == null) return;
    setState(() => _viewingResume = true);
    try {
      await context.read<ProfileService>().viewOwnResume(fileName: _resume!.fileName);
    } on ApiException catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
      }
    } finally {
      if (mounted) setState(() => _viewingResume = false);
    }
  }

  Future<void> _logout() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Log Out'),
        content: const Text('Are you sure you want to log out?'),
        actions: [
          TextButton(onPressed: () => Navigator.of(context).pop(false), child: const Text('Cancel')),
          TextButton(onPressed: () => Navigator.of(context).pop(true), child: const Text('Log Out')),
        ],
      ),
    );
    if (confirmed != true) return;

    await context.read<AuthService>().logout();
    if (!mounted) return;
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const LoginScreen()),
      (route) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    final mobile = context.watch<AuthService>().currentUser?.mobile ?? '';

    return Scaffold(
      appBar: AppBar(title: const Text('Profile')),
      body: _loading
          ? const LoadingView()
          : _error != null
              ? ErrorView(message: _error!, onRetry: _load)
              : SingleChildScrollView(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Center(
                        child: Stack(
                          children: [
                            CircleAvatar(
                              radius: 44,
                              backgroundColor: AppColors.navyLight,
                              backgroundImage:
                                  (_profile?.photoUrl != null) ? NetworkImage(_profile!.photoUrl!) : null,
                              child: _profile?.photoUrl == null
                                  ? const Icon(Icons.person, color: Colors.white, size: 40)
                                  : null,
                            ),
                            Positioned(
                              bottom: 0,
                              right: 0,
                              child: InkWell(
                                onTap: _uploadingPhoto ? null : _pickAndUploadPhoto,
                                borderRadius: BorderRadius.circular(20),
                                child: Container(
                                  padding: const EdgeInsets.all(6),
                                  decoration: const BoxDecoration(color: AppColors.teal, shape: BoxShape.circle),
                                  child: _uploadingPhoto
                                      ? const SizedBox(
                                          height: 14,
                                          width: 14,
                                          child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                                        )
                                      : const Icon(Icons.camera_alt, color: Colors.white, size: 16),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 8),
                      Center(
                        child: Text(mobile, style: const TextStyle(color: AppColors.textMuted, fontSize: 13.5)),
                      ),
                      const SizedBox(height: 20),
                      TextField(controller: _nameController, decoration: const InputDecoration(labelText: 'Name')),
                      const SizedBox(height: 12),
                      TextField(
                        controller: _emailController,
                        keyboardType: TextInputType.emailAddress,
                        decoration: const InputDecoration(labelText: 'Email'),
                      ),
                      const SizedBox(height: 12),
                      TextField(
                        controller: _addressController,
                        maxLines: 2,
                        decoration: const InputDecoration(labelText: 'Address'),
                      ),
                      const SizedBox(height: 12),
                      TextField(
                        controller: _qualificationController,
                        decoration: const InputDecoration(labelText: 'Qualification'),
                      ),
                      const SizedBox(height: 12),
                      TextField(
                        controller: _experienceController,
                        decoration: const InputDecoration(labelText: 'Experience'),
                      ),
                      const SizedBox(height: 12),
                      TextField(
                        controller: _skillsController,
                        maxLines: 2,
                        decoration: const InputDecoration(labelText: 'Skills'),
                      ),
                      const SizedBox(height: 12),
                      TextField(
                        controller: _aboutController,
                        maxLines: 3,
                        decoration: const InputDecoration(labelText: 'About Yourself'),
                      ),
                      const SizedBox(height: 16),
                      ElevatedButton(
                        onPressed: _saving ? null : _save,
                        child: _saving
                            ? const SizedBox(
                                height: 18,
                                width: 18,
                                child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                              )
                            : const Text('Save Profile'),
                      ),
                      const SizedBox(height: 24),
                      const Text('Resume', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
                      const SizedBox(height: 8),
                      Card(
                        child: Padding(
                          padding: const EdgeInsets.all(14),
                          child: Row(
                            children: [
                              const Icon(Icons.description_outlined, color: AppColors.tealDark),
                              const SizedBox(width: 10),
                              Expanded(
                                child: Text(
                                  _resume?.fileName ?? 'No resume uploaded yet',
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(fontSize: 13.5),
                                ),
                              ),
                              if (_resume != null)
                                IconButton(
                                  onPressed: _viewingResume ? null : _viewResume,
                                  icon: _viewingResume
                                      ? const SizedBox(
                                          height: 16,
                                          width: 16,
                                          child: CircularProgressIndicator(strokeWidth: 2),
                                        )
                                      : const Icon(Icons.visibility_outlined),
                                ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(height: 8),
                      OutlinedButton.icon(
                        onPressed: _uploadingResume ? null : _pickAndUploadResume,
                        icon: _uploadingResume
                            ? const SizedBox(height: 14, width: 14, child: CircularProgressIndicator(strokeWidth: 2))
                            : const Icon(Icons.upload_file_outlined, size: 18),
                        label: Text(_resume == null ? 'Upload Resume' : 'Replace Resume'),
                      ),
                      const SizedBox(height: 24),
                      ListTile(
                        contentPadding: EdgeInsets.zero,
                        leading: const Icon(Icons.lock_outline, color: AppColors.navy),
                        title: const Text('Change Password'),
                        trailing: const Icon(Icons.chevron_right),
                        onTap: () => Navigator.of(context)
                            .push(MaterialPageRoute(builder: (_) => const ChangePasswordScreen())),
                      ),
                      ListTile(
                        contentPadding: EdgeInsets.zero,
                        leading: const Icon(Icons.logout, color: AppColors.red),
                        title: const Text('Logout', style: TextStyle(color: AppColors.red)),
                        onTap: _logout,
                      ),
                      const SizedBox(height: 20),
                    ],
                  ),
                ),
    );
  }
}
