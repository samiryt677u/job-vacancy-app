import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/api/api_exception.dart';
import '../../core/models/category.dart';
import '../../core/services/vacancy_service.dart';
import '../../core/theme/app_theme.dart';
import '../../shared/widgets/async_state_views.dart';

class PostVacancyScreen extends StatefulWidget {
  const PostVacancyScreen({super.key});

  @override
  State<PostVacancyScreen> createState() => _PostVacancyScreenState();
}

class _PostVacancyScreenState extends State<PostVacancyScreen> {
  final _formKey = GlobalKey<FormState>();

  final _companyController = TextEditingController();
  final _titleController = TextEditingController();
  final _stateController = TextEditingController();
  final _cityController = TextEditingController();
  final _salaryController = TextEditingController();
  final _ageController = TextEditingController();
  final _qualificationController = TextEditingController();
  final _experienceController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _contactPersonController = TextEditingController();
  final _contactNumberController = TextEditingController();

  bool _loadingCategories = true;
  String? _categoryError;
  CategoryData? _categoryData;
  int? _selectedCategoryId;
  int? _selectedSubcategoryId;

  bool _submitting = false;
  Map<String, dynamic> _fieldErrors = {};

  @override
  void initState() {
    super.initState();
    _loadCategories();
  }

  @override
  void dispose() {
    _companyController.dispose();
    _titleController.dispose();
    _stateController.dispose();
    _cityController.dispose();
    _salaryController.dispose();
    _ageController.dispose();
    _qualificationController.dispose();
    _experienceController.dispose();
    _descriptionController.dispose();
    _contactPersonController.dispose();
    _contactNumberController.dispose();
    super.dispose();
  }

  Future<void> _loadCategories() async {
    setState(() {
      _loadingCategories = true;
      _categoryError = null;
    });
    try {
      final data = await context.read<VacancyService>().getCategories();
      setState(() => _categoryData = data);
    } on ApiException catch (e) {
      setState(() => _categoryError = e.message);
    } finally {
      if (mounted) setState(() => _loadingCategories = false);
    }
  }

  Future<void> _submit() async {
    final formValid = _formKey.currentState!.validate();
    if (_selectedCategoryId == null) {
      setState(() => _fieldErrors = {'category_id': 'Please select a category'});
    }
    if (!formValid || _selectedCategoryId == null) return;

    setState(() {
      _submitting = true;
      _fieldErrors = {};
    });

    try {
      await context.read<VacancyService>().create({
        'company_name': _companyController.text.trim(),
        'job_title': _titleController.text.trim(),
        'category_id': _selectedCategoryId,
        if (_selectedSubcategoryId != null) 'subcategory_id': _selectedSubcategoryId,
        'state': _stateController.text.trim(),
        'city': _cityController.text.trim(),
        'salary': _salaryController.text.trim(),
        'age_limit': _ageController.text.trim(),
        'qualification': _qualificationController.text.trim(),
        'experience': _experienceController.text.trim(),
        'job_description': _descriptionController.text.trim(),
        'contact_person': _contactPersonController.text.trim(),
        'contact_number': _contactNumberController.text.trim(),
      });

      if (!mounted) return;
      _resetForm();

      await showDialog<void>(
        context: context,
        builder: (_) => AlertDialog(
          title: const Text('Vacancy Submitted'),
          content: const Text(
            'Your vacancy has been submitted for admin approval. It will appear on Home once approved and published.',
          ),
          actions: [
            TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('OK')),
          ],
        ),
      );
    } on ApiException catch (e) {
      setState(() => _fieldErrors = e.fieldErrors);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
      }
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  void _resetForm() {
    _formKey.currentState!.reset();
    for (final c in [
      _companyController,
      _titleController,
      _stateController,
      _cityController,
      _salaryController,
      _ageController,
      _qualificationController,
      _experienceController,
      _descriptionController,
      _contactPersonController,
      _contactNumberController,
    ]) {
      c.clear();
    }
    setState(() {
      _selectedCategoryId = null;
      _selectedSubcategoryId = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Post Vacancy')),
      body: _loadingCategories
          ? const LoadingView()
          : _categoryError != null
              ? ErrorView(message: _categoryError!, onRetry: _loadCategories)
              : _buildForm(),
    );
  }

  Widget _buildForm() {
    final categories = _categoryData!.categories;
    final subcategories =
        _selectedCategoryId != null ? _categoryData!.subcategoriesFor(_selectedCategoryId!) : <JobSubcategory>[];

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Form(
        key: _formKey,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            _field(_companyController, 'Company Name', required: true),
            const SizedBox(height: 12),
            _field(_titleController, 'Job Title / Post', required: true),
            const SizedBox(height: 12),
            DropdownButtonFormField<int>(
              value: _selectedCategoryId,
              decoration: InputDecoration(
                labelText: 'Category',
                errorText: _fieldErrors['category_id'] as String?,
              ),
              items: categories.map((c) => DropdownMenuItem(value: c.id, child: Text(c.name))).toList(),
              onChanged: (value) => setState(() {
                _selectedCategoryId = value;
                _selectedSubcategoryId = null;
              }),
            ),
            if (subcategories.isNotEmpty) ...[
              const SizedBox(height: 12),
              DropdownButtonFormField<int>(
                value: _selectedSubcategoryId,
                decoration: const InputDecoration(labelText: 'Subcategory (optional)'),
                items: subcategories.map((s) => DropdownMenuItem(value: s.id, child: Text(s.name))).toList(),
                onChanged: (value) => setState(() => _selectedSubcategoryId = value),
              ),
            ],
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(child: _field(_stateController, 'State', required: true)),
                const SizedBox(width: 12),
                Expanded(child: _field(_cityController, 'City / HQ', required: true)),
              ],
            ),
            const SizedBox(height: 12),
            _field(_salaryController, 'Salary (e.g. 15000-20000)'),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(child: _field(_ageController, 'Age Limit')),
                const SizedBox(width: 12),
                Expanded(child: _field(_experienceController, 'Experience')),
              ],
            ),
            const SizedBox(height: 12),
            _field(_qualificationController, 'Qualification'),
            const SizedBox(height: 12),
            _field(_descriptionController, 'Job Description', required: true, maxLines: 5),
            const SizedBox(height: 12),
            _field(_contactPersonController, 'Contact Person', required: true),
            const SizedBox(height: 12),
            _field(
              _contactNumberController,
              'Contact Number',
              required: true,
              keyboardType: TextInputType.phone,
            ),
            const SizedBox(height: 22),
            ElevatedButton(
              onPressed: _submitting ? null : _submit,
              child: _submitting
                  ? const SizedBox(
                      height: 18,
                      width: 18,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                    )
                  : const Text('Submit Vacancy'),
            ),
            const SizedBox(height: 8),
            const Text(
              'Your vacancy will be reviewed by an admin before it appears on Home.',
              textAlign: TextAlign.center,
              style: TextStyle(color: AppColors.textMuted, fontSize: 12.5),
            ),
          ],
        ),
      ),
    );
  }

  Widget _field(
    TextEditingController controller,
    String label, {
    bool required = false,
    int maxLines = 1,
    TextInputType? keyboardType,
  }) {
    return TextFormField(
      controller: controller,
      maxLines: maxLines,
      keyboardType: keyboardType,
      decoration: InputDecoration(labelText: required ? '$label *' : label),
      validator: required ? (v) => (v == null || v.trim().isEmpty) ? '$label is required' : null : null,
    );
  }
}
