import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/api/api_exception.dart';
import '../../core/models/vacancy.dart';
import '../../core/services/application_service.dart';
import '../../core/services/vacancy_service.dart';
import '../../core/theme/app_theme.dart';
import '../../shared/widgets/async_state_views.dart';

class VacancyDetailScreen extends StatefulWidget {
  final int vacancyId;

  const VacancyDetailScreen({super.key, required this.vacancyId});

  @override
  State<VacancyDetailScreen> createState() => _VacancyDetailScreenState();
}

class _VacancyDetailScreenState extends State<VacancyDetailScreen> {
  bool _loading = true;
  String? _error;
  VacancyDetail? _vacancy;
  bool _applying = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final vacancy = await context.read<VacancyService>().getDetail(widget.vacancyId);
      setState(() => _vacancy = vacancy);
    } on ApiException catch (e) {
      setState(() => _error = e.message);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _apply() async {
    setState(() => _applying = true);
    try {
      await context.read<ApplicationService>().apply(widget.vacancyId);
      if (!mounted) return;
      setState(() {
        _vacancy = VacancyDetail(
          id: _vacancy!.id,
          companyName: _vacancy!.companyName,
          jobTitle: _vacancy!.jobTitle,
          category: _vacancy!.category,
          subcategory: _vacancy!.subcategory,
          state: _vacancy!.state,
          city: _vacancy!.city,
          salary: _vacancy!.salary,
          ageLimit: _vacancy!.ageLimit,
          qualification: _vacancy!.qualification,
          experience: _vacancy!.experience,
          jobDescription: _vacancy!.jobDescription,
          contactPerson: _vacancy!.contactPerson,
          contactNumber: _vacancy!.contactNumber,
          postedAt: _vacancy!.postedAt,
          alreadyApplied: true,
        );
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Application submitted successfully!')),
      );
    } on ApiException catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
      }
    } finally {
      if (mounted) setState(() => _applying = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Vacancy Details')),
      body: _loading
          ? const LoadingView()
          : _error != null
              ? ErrorView(message: _error!, onRetry: _load)
              : _buildContent(_vacancy!),
      bottomNavigationBar: (!_loading && _vacancy != null) ? _buildApplyBar(_vacancy!) : null,
    );
  }

  Widget _buildContent(VacancyDetail v) {
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(v.jobTitle, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 4),
          Text(v.companyName, style: const TextStyle(fontSize: 15, color: AppColors.textMuted)),
          const SizedBox(height: 14),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              if (v.category != null) _Pill(icon: Icons.category_outlined, label: v.category!),
              _Pill(icon: Icons.location_on_outlined, label: '${v.city}, ${v.state}'),
              if (v.salary != null && v.salary!.isNotEmpty)
                _Pill(icon: Icons.currency_rupee, label: v.salary!),
            ],
          ),
          const SizedBox(height: 20),
          _DetailGrid(v: v),
          const SizedBox(height: 20),
          const Text('Job Description', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
          const SizedBox(height: 6),
          Text(v.jobDescription, style: const TextStyle(fontSize: 14, height: 1.5)),
          const SizedBox(height: 20),
          const Text('Contact', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
          const SizedBox(height: 6),
          Text('${v.contactPerson} · ${v.contactNumber}', style: const TextStyle(fontSize: 14)),
        ],
      ),
    );
  }

  Widget _buildApplyBar(VacancyDetail v) {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 10, 16, 10),
        child: ElevatedButton(
          onPressed: (v.alreadyApplied || _applying) ? null : _apply,
          child: _applying
              ? const SizedBox(
                  height: 18,
                  width: 18,
                  child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                )
              : Text(v.alreadyApplied ? 'Already Applied' : 'Apply Now'),
        ),
      ),
    );
  }
}

class _DetailGrid extends StatelessWidget {
  final VacancyDetail v;
  const _DetailGrid({required this.v});

  @override
  Widget build(BuildContext context) {
    final rows = <MapEntry<String, String>>[
      if (v.qualification != null && v.qualification!.isNotEmpty) MapEntry('Qualification', v.qualification!),
      if (v.experience != null && v.experience!.isNotEmpty) MapEntry('Experience', v.experience!),
      if (v.ageLimit != null && v.ageLimit!.isNotEmpty) MapEntry('Age Limit', v.ageLimit!),
      if (v.subcategory != null && v.subcategory!.isNotEmpty) MapEntry('Role Type', v.subcategory!),
    ];
    if (rows.isEmpty) return const SizedBox.shrink();

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        children: rows
            .map((e) => Padding(
                  padding: const EdgeInsets.symmetric(vertical: 4),
                  child: Row(
                    children: [
                      Expanded(
                        child: Text(e.key, style: const TextStyle(color: AppColors.textMuted, fontSize: 13.5)),
                      ),
                      Expanded(
                        child: Text(
                          e.value,
                          textAlign: TextAlign.right,
                          style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13.5),
                        ),
                      ),
                    ],
                  ),
                ))
            .toList(),
      ),
    );
  }
}

class _Pill extends StatelessWidget {
  final IconData icon;
  final String label;
  const _Pill({required this.icon, required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: AppColors.paper,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 14, color: AppColors.tealDark),
          const SizedBox(width: 4),
          Text(label, style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}
