import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/api/api_exception.dart';
import '../../core/models/vacancy.dart';
import '../../core/services/vacancy_service.dart';
import '../../core/theme/app_theme.dart';
import '../../shared/widgets/async_state_views.dart';
import '../../shared/widgets/status_badge.dart';
import 'applicants_screen.dart';

class MyPostedJobsScreen extends StatefulWidget {
  const MyPostedJobsScreen({super.key});

  @override
  State<MyPostedJobsScreen> createState() => _MyPostedJobsScreenState();
}

class _MyPostedJobsScreenState extends State<MyPostedJobsScreen> {
  bool _loading = true;
  String? _error;
  List<MyPostedVacancy> _vacancies = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final vacancies = await context.read<VacancyService>().getMyPosted();
      setState(() => _vacancies = vacancies);
    } on ApiException catch (e) {
      setState(() => _error = e.message);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('My Posted Jobs')),
      body: _loading
          ? const LoadingView()
          : _error != null
              ? ErrorView(message: _error!, onRetry: _load)
              : _vacancies.isEmpty
                  ? const EmptyView(
                      message: "You haven't posted any vacancy yet.\nTap the Post Job tab to create one.",
                      icon: Icons.work_outline,
                    )
                  : RefreshIndicator(
                      onRefresh: _load,
                      child: ListView.separated(
                        padding: const EdgeInsets.all(16),
                        itemCount: _vacancies.length,
                        separatorBuilder: (_, __) => const SizedBox(height: 10),
                        itemBuilder: (context, index) {
                          final v = _vacancies[index];
                          return _PostedJobCard(
                            vacancy: v,
                            onTap: () => Navigator.of(context).push(
                              MaterialPageRoute(
                                builder: (_) => ApplicantsScreen(vacancyId: v.id, jobTitleFallback: v.jobTitle),
                              ),
                            ),
                          );
                        },
                      ),
                    ),
    );
  }
}

class _PostedJobCard extends StatelessWidget {
  final MyPostedVacancy vacancy;
  final VoidCallback onTap;

  const _PostedJobCard({required this.vacancy, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(
                      vacancy.jobTitle,
                      style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15),
                    ),
                  ),
                  StatusBadge(
                    label: vacancy.approvalStatus[0].toUpperCase() + vacancy.approvalStatus.substring(1),
                    color: StatusColors.forApprovalStatus(vacancy.approvalStatus),
                  ),
                ],
              ),
              const SizedBox(height: 4),
              Text(vacancy.companyName, style: const TextStyle(color: AppColors.textMuted, fontSize: 13.5)),
              const SizedBox(height: 4),
              Text('${vacancy.city}, ${vacancy.state}', style: const TextStyle(color: AppColors.textMuted, fontSize: 12.5)),
              if (vacancy.approvalStatus == 'rejected' && (vacancy.rejectionReason ?? '').isNotEmpty) ...[
                const SizedBox(height: 6),
                Text(
                  'Reason: ${vacancy.rejectionReason}',
                  style: const TextStyle(color: AppColors.red, fontSize: 12.5),
                ),
              ],
              const SizedBox(height: 10),
              Row(
                children: [
                  Icon(
                    vacancy.publishStatus == 'published' ? Icons.visibility_outlined : Icons.visibility_off_outlined,
                    size: 15,
                    color: AppColors.textMuted,
                  ),
                  const SizedBox(width: 4),
                  Text(
                    vacancy.publishStatus == 'published' ? 'Live on Home' : 'Not published yet',
                    style: const TextStyle(fontSize: 12, color: AppColors.textMuted),
                  ),
                  const Spacer(),
                  Icon(Icons.people_outline, size: 15, color: AppColors.tealDark),
                  const SizedBox(width: 4),
                  Text(
                    '${vacancy.applicantCount} applicant${vacancy.applicantCount == 1 ? '' : 's'}',
                    style: const TextStyle(fontSize: 12.5, color: AppColors.tealDark, fontWeight: FontWeight.w600),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
