import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/api/api_exception.dart';
import '../../core/config.dart';
import '../../core/models/application.dart';
import '../../core/services/application_service.dart';
import '../../core/services/vacancy_service.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/date_fmt.dart';
import '../../shared/widgets/async_state_views.dart';
import '../../shared/widgets/status_badge.dart';

class ApplicantsScreen extends StatefulWidget {
  final int vacancyId;
  final String jobTitleFallback;

  const ApplicantsScreen({super.key, required this.vacancyId, required this.jobTitleFallback});

  @override
  State<ApplicantsScreen> createState() => _ApplicantsScreenState();
}

class _ApplicantsScreenState extends State<ApplicantsScreen> {
  bool _loading = true;
  String? _error;
  String? _jobTitle;
  List<Applicant> _applicants = [];
  final Set<int> _updatingIds = {};
  final Set<int> _viewingResumeIds = {};

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final result = await context.read<VacancyService>().getApplicants(widget.vacancyId);
      setState(() {
        _jobTitle = result.jobTitle;
        _applicants = result.applicants;
      });
    } on ApiException catch (e) {
      setState(() => _error = e.message);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _updateStatus(Applicant applicant, String newStatus) async {
    setState(() => _updatingIds.add(applicant.applicationId));
    try {
      await context.read<ApplicationService>().updateStatus(
            applicationId: applicant.applicationId,
            status: newStatus,
          );
      setState(() {
        final index = _applicants.indexWhere((a) => a.applicationId == applicant.applicationId);
        if (index != -1) {
          _applicants[index] = Applicant(
            applicationId: applicant.applicationId,
            name: applicant.name,
            mobile: applicant.mobile,
            qualification: applicant.qualification,
            experience: applicant.experience,
            resumeId: applicant.resumeId,
            resumeFileName: applicant.resumeFileName,
            resumeFileType: applicant.resumeFileType,
            status: newStatus,
            appliedAt: applicant.appliedAt,
          );
        }
      });
    } on ApiException catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
      }
    } finally {
      if (mounted) setState(() => _updatingIds.remove(applicant.applicationId));
    }
  }

  Future<void> _viewResume(Applicant applicant) async {
    setState(() => _viewingResumeIds.add(applicant.applicationId));
    try {
      await context.read<ApplicationService>().viewApplicantResume(
            applicationId: applicant.applicationId,
            fileName: applicant.resumeFileName ?? 'resume.${applicant.resumeFileType ?? 'pdf'}',
          );
    } on ApiException catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
      }
    } finally {
      if (mounted) setState(() => _viewingResumeIds.remove(applicant.applicationId));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(_jobTitle ?? widget.jobTitleFallback)),
      body: _loading
          ? const LoadingView()
          : _error != null
              ? ErrorView(message: _error!, onRetry: _load)
              : _applicants.isEmpty
                  ? const EmptyView(
                      message: 'No applications received yet for this vacancy.',
                      icon: Icons.people_outline,
                    )
                  : RefreshIndicator(
                      onRefresh: _load,
                      child: ListView.separated(
                        padding: const EdgeInsets.all(16),
                        itemCount: _applicants.length,
                        separatorBuilder: (_, __) => const SizedBox(height: 10),
                        itemBuilder: (context, index) {
                          final applicant = _applicants[index];
                          final isUpdating = _updatingIds.contains(applicant.applicationId);
                          final isViewingResume = _viewingResumeIds.contains(applicant.applicationId);

                          return Card(
                            child: Padding(
                              padding: const EdgeInsets.all(14),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      Expanded(
                                        child: Text(
                                          applicant.name?.isNotEmpty == true ? applicant.name! : 'Unnamed applicant',
                                          style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15),
                                        ),
                                      ),
                                      StatusBadge(
                                        label: applicant.status[0].toUpperCase() + applicant.status.substring(1),
                                        color: StatusColors.forApplicationStatus(applicant.status),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 4),
                                  Text(applicant.mobile, style: const TextStyle(color: AppColors.textMuted, fontSize: 13.5)),
                                  if ((applicant.qualification ?? '').isNotEmpty || (applicant.experience ?? '').isNotEmpty) ...[
                                    const SizedBox(height: 4),
                                    Text(
                                      [applicant.qualification, applicant.experience]
                                          .where((e) => e != null && e.isNotEmpty)
                                          .join(' · '),
                                      style: const TextStyle(color: AppColors.textMuted, fontSize: 12.5),
                                    ),
                                  ],
                                  const SizedBox(height: 4),
                                  Row(
                                    children: [
                                      const Icon(Icons.event_outlined, size: 13, color: AppColors.textMuted),
                                      const SizedBox(width: 4),
                                      Text(
                                        'Applied on ${DateFmt.short(applicant.appliedAt)}',
                                        style: const TextStyle(fontSize: 12, color: AppColors.textMuted),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 12),
                                  Row(
                                    children: [
                                      Expanded(
                                        child: OutlinedButton.icon(
                                          onPressed: (!applicant.hasResume || isViewingResume)
                                              ? null
                                              : () => _viewResume(applicant),
                                          icon: isViewingResume
                                              ? const SizedBox(
                                                  height: 14,
                                                  width: 14,
                                                  child: CircularProgressIndicator(strokeWidth: 2),
                                                )
                                              : const Icon(Icons.description_outlined, size: 16),
                                          label: Text(applicant.hasResume ? 'View Resume' : 'No Resume'),
                                        ),
                                      ),
                                      const SizedBox(width: 10),
                                      Expanded(
                                        child: DropdownButtonFormField<String>(
                                          value: applicant.status,
                                          isDense: true,
                                          decoration: const InputDecoration(
                                            contentPadding: EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                                          ),
                                          items: AppConfig.applicationStatuses
                                              .map((s) => DropdownMenuItem(
                                                    value: s,
                                                    child: Text(s[0].toUpperCase() + s.substring(1)),
                                                  ))
                                              .toList(),
                                          onChanged: isUpdating
                                              ? null
                                              : (value) {
                                                  if (value != null && value != applicant.status) {
                                                    _updateStatus(applicant, value);
                                                  }
                                                },
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
                    ),
    );
  }
}
