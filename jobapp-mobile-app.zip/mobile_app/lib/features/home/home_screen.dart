import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/api/api_exception.dart';
import '../../core/models/vacancy.dart';
import '../../core/services/vacancy_service.dart';
import '../../core/theme/app_theme.dart';
import '../../shared/widgets/async_state_views.dart';
import '../vacancy/vacancy_detail_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _searchController = TextEditingController();
  final _locationController = TextEditingController();

  bool _loading = true;
  bool _loadingMore = false;
  String? _error;
  List<VacancySummary> _vacancies = [];
  int _page = 1;
  int _totalPages = 1;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _searchController.dispose();
    _locationController.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final result = await context.read<VacancyService>().getHomeFeed(
            query: _searchController.text.trim(),
            location: _locationController.text.trim(),
            page: 1,
          );
      setState(() {
        _vacancies = result.vacancies;
        _page = result.page;
        _totalPages = result.totalPages;
      });
    } on ApiException catch (e) {
      setState(() => _error = e.message);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _loadMore() async {
    if (_page >= _totalPages || _loadingMore) return;
    setState(() => _loadingMore = true);
    try {
      final result = await context.read<VacancyService>().getHomeFeed(
            query: _searchController.text.trim(),
            location: _locationController.text.trim(),
            page: _page + 1,
          );
      setState(() {
        _vacancies = [..._vacancies, ...result.vacancies];
        _page = result.page;
        _totalPages = result.totalPages;
      });
    } on ApiException catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
      }
    } finally {
      if (mounted) setState(() => _loadingMore = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Find Jobs')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
            child: Column(
              children: [
                TextField(
                  controller: _searchController,
                  decoration: InputDecoration(
                    hintText: 'Search job title or company',
                    prefixIcon: const Icon(Icons.search),
                    suffixIcon: _searchController.text.isNotEmpty
                        ? IconButton(
                            icon: const Icon(Icons.clear),
                            onPressed: () {
                              _searchController.clear();
                              _load();
                            },
                          )
                        : null,
                  ),
                  onSubmitted: (_) => _load(),
                ),
                const SizedBox(height: 8),
                TextField(
                  controller: _locationController,
                  decoration: InputDecoration(
                    hintText: 'City or state',
                    prefixIcon: const Icon(Icons.location_on_outlined),
                    suffixIcon: _locationController.text.isNotEmpty
                        ? IconButton(
                            icon: const Icon(Icons.clear),
                            onPressed: () {
                              _locationController.clear();
                              _load();
                            },
                          )
                        : null,
                  ),
                  onSubmitted: (_) => _load(),
                ),
              ],
            ),
          ),
          Expanded(child: _buildBody()),
        ],
      ),
    );
  }

  Widget _buildBody() {
    if (_loading) return const LoadingView();
    if (_error != null) return ErrorView(message: _error!, onRetry: _load);
    if (_vacancies.isEmpty) {
      return const EmptyView(
        message: 'No vacancies found.\nTry a different search or check back later.',
        icon: Icons.work_off_outlined,
      );
    }

    return RefreshIndicator(
      onRefresh: _load,
      child: ListView.separated(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 16),
        itemCount: _vacancies.length + 1,
        separatorBuilder: (_, __) => const SizedBox(height: 10),
        itemBuilder: (context, index) {
          if (index == _vacancies.length) {
            if (_page < _totalPages) {
              return Padding(
                padding: const EdgeInsets.symmetric(vertical: 12),
                child: Center(
                  child: _loadingMore
                      ? const CircularProgressIndicator()
                      : OutlinedButton(onPressed: _loadMore, child: const Text('Load More')),
                ),
              );
            }
            return const SizedBox.shrink();
          }
          final vacancy = _vacancies[index];
          return _VacancyCard(
            vacancy: vacancy,
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => VacancyDetailScreen(vacancyId: vacancy.id)),
            ),
          );
        },
      ),
    );
  }
}

class _VacancyCard extends StatelessWidget {
  final VacancySummary vacancy;
  final VoidCallback onTap;

  const _VacancyCard({required this.vacancy, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Text(
                      vacancy.jobTitle,
                      style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15.5),
                    ),
                  ),
                  if (vacancy.category.isNotEmpty)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(
                        color: AppColors.teal.withValues(alpha: 0.1),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text(
                        vacancy.category,
                        style: const TextStyle(color: AppColors.tealDark, fontSize: 11, fontWeight: FontWeight.w600),
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 4),
              Text(vacancy.companyName, style: const TextStyle(color: AppColors.textMuted, fontSize: 13.5)),
              const SizedBox(height: 8),
              Wrap(
                spacing: 14,
                runSpacing: 4,
                children: [
                  _InfoChip(icon: Icons.location_on_outlined, label: '${vacancy.city}, ${vacancy.state}'),
                  if (vacancy.salary != null && vacancy.salary!.isNotEmpty)
                    _InfoChip(icon: Icons.currency_rupee, label: vacancy.salary!),
                  if (vacancy.experience != null && vacancy.experience!.isNotEmpty)
                    _InfoChip(icon: Icons.work_history_outlined, label: vacancy.experience!),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _InfoChip extends StatelessWidget {
  final IconData icon;
  final String label;

  const _InfoChip({required this.icon, required this.label});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, size: 14, color: AppColors.textMuted),
        const SizedBox(width: 3),
        Text(label, style: const TextStyle(fontSize: 12.5, color: AppColors.textMuted)),
      ],
    );
  }
}
