import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/api/api_exception.dart';
import '../../core/models/application.dart';
import '../../core/services/application_service.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/date_fmt.dart';
import '../../shared/widgets/async_state_views.dart';
import '../../shared/widgets/status_badge.dart';
import '../vacancy/vacancy_detail_screen.dart';

class MyApplicationsScreen extends StatefulWidget {
  const MyApplicationsScreen({super.key});

  @override
  State<MyApplicationsScreen> createState() => _MyApplicationsScreenState();
}

class _MyApplicationsScreenState extends State<MyApplicationsScreen> {
  bool _loading = true;
  String? _error;
  List<MyApplication> _applications = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final apps = await context.read<ApplicationService>().getMyApplications();
      setState(() => _applications = apps);
    } on ApiException catch (e) {
      setState(() => _error = e.message);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('My Applications')),
      body: _loading
          ? const LoadingView()
          : _error != null
              ? ErrorView(message: _error!, onRetry: _load)
              : _applications.isEmpty
                  ? const EmptyView(
                      message: "You haven't applied to any jobs yet.",
                      icon: Icons.description_outlined,
                    )
                  : RefreshIndicator(
                      onRefresh: _load,
                      child: ListView.separated(
                        padding: const EdgeInsets.all(16),
                        itemCount: _applications.length,
                        separatorBuilder: (_, __) => const SizedBox(height: 10),
                        itemBuilder: (context, index) {
                          final app = _applications[index];
                          return Card(
                            child: InkWell(
                              borderRadius: BorderRadius.circular(12),
                              onTap: () => Navigator.of(context).push(
                                MaterialPageRoute(
                                  builder: (_) => VacancyDetailScreen(vacancyId: app.vacancyId),
                                ),
                              ),
                              child: Padding(
                                padding: const EdgeInsets.all(14),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      children: [
                                        Expanded(
                                          child: Text(
                                            app.jobTitle,
                                            style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15),
                                          ),
                                        ),
                                        StatusBadge(
                                          label: app.status[0].toUpperCase() + app.status.substring(1),
                                          color: StatusColors.forApplicationStatus(app.status),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(height: 4),
                                    Text(app.companyName, style: const TextStyle(color: AppColors.textMuted, fontSize: 13.5)),
                                    const SizedBox(height: 4),
                                    Text(
                                      '${app.city}, ${app.state}',
                                      style: const TextStyle(color: AppColors.textMuted, fontSize: 12.5),
                                    ),
                                    const SizedBox(height: 6),
                                    Row(
                                      children: [
                                        const Icon(Icons.event_outlined, size: 13, color: AppColors.textMuted),
                                        const SizedBox(width: 4),
                                        Text(
                                          'Applied on ${DateFmt.short(app.appliedAt)}',
                                          style: const TextStyle(fontSize: 12, color: AppColors.textMuted),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          );
                        },
                      ),
                    ),
    );
  }
}
